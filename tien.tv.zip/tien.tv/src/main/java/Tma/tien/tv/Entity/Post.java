package Tma.tien.tv.Entity;

import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.Date;

@Entity
@Table(name = "post")
public class Post {

    private int id;
    private String title;
    private String content;
    private Date datePost;
    private User author;

    public Post() {
    }

    public Post(int id, String title, String content, Date datePost) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.datePost = datePost;
    }
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Post_Id", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    @Column(name = "Title", nullable = false)
    @NotEmpty(message = "*please input this field")
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    @Column(name = "Content",nullable = false)
    @NotEmpty(message = "*please input content post")
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Column(name = "Date")
    @Temporal(TemporalType.DATE
    )
    public Date getDatePost() {
        return datePost;
    }

    public void setDatePost(Date datePost) {
        this.datePost = datePost;
    }
    @ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JoinColumn(name = "User_Id")
    public User getAuthor() {
        return author;
    }

    public void setAuthor(User author) {
        this.author = author;
    }
}
