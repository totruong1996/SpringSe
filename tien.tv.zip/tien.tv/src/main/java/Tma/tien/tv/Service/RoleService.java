package Tma.tien.tv.Service;

import Tma.tien.tv.Entity.Role;

public interface RoleService {
    public Role findByRole(String role);
}
