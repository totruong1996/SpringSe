package Tma.tien.tv.Controller;

import Tma.tien.tv.Entity.Role;
import Tma.tien.tv.Entity.User;
import Tma.tien.tv.Repository.RoleRepository;
import Tma.tien.tv.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.jws.WebParam;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Controller
@RequestMapping(path = "/Admin")
public class AdminController {
    @Autowired
    private UserService userService;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;


    @GetMapping(path = "/addUser")
    public ModelAndView showViewAddUser() {
        ModelAndView modelAndView = new ModelAndView();
        Iterable<Role> roles = roleRepository.findAll();

        User user = new User();
        modelAndView.addObject("user", user);
        modelAndView.addObject("roles", roles);
        modelAndView.setViewName("addUser");
        return modelAndView;
    }

    @PostMapping(path = "/addUser")
    public ModelAndView SaveUser(@Valid @ModelAttribute("user") User user, BindingResult result, HttpServletRequest request) {
        Iterable<Role> roles = roleRepository.findAll();
        ModelAndView modelAndView = new ModelAndView();
        User u = userService.findByEmail(user.getEmail());
        if ((u != null)) {
            modelAndView.addObject("error", "User is already register!");
            modelAndView.addObject("roles", roles);
            modelAndView.setViewName("addUser");
        } else {
            if (result.hasErrors()) {

                modelAndView.addObject("roles", roles);
                modelAndView.setViewName("addUser");
            } else {
                String[] role = request.getParameterValues("role");
                Set<Role> roleUser = new HashSet<>();
                for (String r : role) {
                    roleUser.add(roleRepository.findByRole(r.split("_")[1]));

                }
                user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
                user.setRoles(roleUser);
                userService.save(user);
                modelAndView.addObject("success", "User has been registered successfully");
                modelAndView.addObject("user", new User());
                modelAndView.addObject("roles", roles);
                modelAndView.setViewName("addUser");
            }
        }
        return modelAndView;
    }
}
