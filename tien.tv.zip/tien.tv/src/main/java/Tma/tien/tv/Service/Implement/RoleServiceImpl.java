package Tma.tien.tv.Service.Implement;

import Tma.tien.tv.Entity.Role;
import Tma.tien.tv.Repository.RoleRepository;
import Tma.tien.tv.Service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RoleServiceImpl implements RoleService {
    @Autowired
    private RoleRepository roleRepository;

    @Override
    public Role findByRole(String role) {
        return roleRepository.findByRole(role);
    }
}
