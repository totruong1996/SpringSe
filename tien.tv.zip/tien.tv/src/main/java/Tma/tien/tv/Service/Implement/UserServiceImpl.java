package Tma.tien.tv.Service.Implement;

import Tma.tien.tv.Entity.User;
import Tma.tien.tv.Repository.UserRepository;
import Tma.tien.tv.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import Tma.tien.tv.Service.UserService;
@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepository;
    @Override
    public User findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    @Override
    public void save(User user) {
        userRepository.save(user);
    }
}
