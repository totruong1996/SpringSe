package Tma.tien.tv.Service;

import Tma.tien.tv.Entity.User;
import org.springframework.beans.factory.annotation.Autowired;

public interface UserService {
    public User findByEmail(String email);
    public void save(User user);

}
