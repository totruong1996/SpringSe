package Tma.tien.tv.Service;

import Tma.tien.tv.Entity.Post;

public interface PostService {
    public void Save(Post post);
    public void Delete(int id);
    public void Update(int id, Post post);

}
