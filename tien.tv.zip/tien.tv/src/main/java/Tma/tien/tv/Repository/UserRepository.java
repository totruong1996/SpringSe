package Tma.tien.tv.Repository;

import Tma.tien.tv.Entity.User;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
@Transactional
public interface UserRepository extends CrudRepository<User, Integer > {

    @Query("select u from User u where u.email = :email and u.name = :name")
    public User findByNameAndEmail(@Param("name") String name,@Param("email") String email);

    @Modifying
    @Query("delete from User where id = ?1")
    public void deleteIdQuery(Integer id);

    @Modifying
    @Query("select u from User u where u.name like %?1")
    public List<User> findByNameQuery(String name);

    @Modifying
    @Query(value = "INSERT INTO user (name ,email) VALUES (?1, ?2)",nativeQuery =true )
    public void insertQuery( String name, String email);

    public User findByEmail(String email);



}
