package Tma.tien.tv.Service.Implement;

import Tma.tien.tv.Entity.Post;
import Tma.tien.tv.Repository.PostRepository;
import Tma.tien.tv.Service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PostServiceImpl implements PostService {
    @Autowired
    private PostRepository postRepository;

    @Override
    public void Save(Post post) {
        postRepository.save(post);

    }

    @Override
    public void Delete(int id) {
        Post post = postRepository.findById(id).orElseGet(() -> new Post());
        if (post != null) {
            postRepository.delete(post);
        }

    }

    @Override
    public void Update(int id, Post post) {
        Post p = postRepository.findById(id).orElseGet(() -> new Post());
        if (p != null) {
            p.setContent(post.getContent());
            p.setDatePost(post.getDatePost());
            p.setTitle(post.getTitle());
            postRepository.save(p);
        }


    }
}
