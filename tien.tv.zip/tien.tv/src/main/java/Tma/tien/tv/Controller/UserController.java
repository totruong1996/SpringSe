package Tma.tien.tv.Controller;

import Tma.tien.tv.Entity.Role;
import Tma.tien.tv.Entity.User;
import Tma.tien.tv.Service.RoleService;
import Tma.tien.tv.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.Arrays;
import java.util.HashSet;

@Controller
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private RoleService roleService;

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;


    @GetMapping(path = "/register")
    public ModelAndView register(){
        ModelAndView modelAndView = new ModelAndView();
        User user = new User();
        modelAndView.addObject("user", user);
        modelAndView.setViewName("registerPage");
        return modelAndView;
    }

    @PostMapping(path = "/register")
    public ModelAndView createUser(@Valid @ModelAttribute("user") User user, BindingResult result) {
        ModelAndView modelAndView = new ModelAndView();
        User u = userService.findByEmail(user.getEmail());
        if(u!=null){
            modelAndView.addObject("error","User is already register!");
            modelAndView.setViewName("registerPage");
        }
        else{
            if(result.hasErrors()){
                modelAndView.setViewName("registerPage");
            }
            else {
                Role role =  roleService.findByRole("USER");
                user.setRoles(new HashSet<>(Arrays.asList(role)));
                user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
                userService.save(user);
                modelAndView.addObject("success","User has been registered successfully");
                modelAndView.addObject("user", new User());
                modelAndView.setViewName("registerPage");
            }

        }
        return modelAndView;
    }

}
