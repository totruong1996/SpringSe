package Tma.tien.tv.Repository;

import Tma.tien.tv.Entity.Role;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface RoleRepository extends CrudRepository<Role, Integer> {
    @Query(" from Role r where r.role like %?1")
    public Role findByRole(String role);
}
